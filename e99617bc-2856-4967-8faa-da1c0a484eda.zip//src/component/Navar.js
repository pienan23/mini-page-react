

export default function Navbar() {
  return (
    <div className="logo">
     <img src="./image/logo.png" alt="" srcset="" />
    </div>
  );
}
